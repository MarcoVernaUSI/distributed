import numpy as np
import matplotlib.pyplot as plt

def get_sequence_inputs(X, window_size=24, horizon=24, shuffle=False):
    """
    Prepare data for feeding a predictor.
    We feed the model with data from day T-1 and forecast the whole day T+1

    :param X: numpy.array or list that contains 2 or 3 tensors:
         - a tensor shape (M, n_features_1), M=n_samples [inputs]
         - a tensor of shape (M, ) [target]
         - (optional) a tensor of shape (M, n_features_2)
    :param window_size: int
        Fixed size of the look-back
    :param horizon: int
        Forecasting horizon, the number of future steps that have to be forecasted
    :param shuffle: if True shuffle the data on the first axis
    :return: tuple
        Return two numpy.arrays: the input and the target for the model.
        - the inputs has shape (N, window_size, n_features)
        - the target has shape (N, horizon)
    """
    X, y = X

    inputs = X.reshape(-1, window_size, X.shape[-1])
    targets = y.reshape(-1, horizon, 1)
    idxs = np.arange(inputs.shape[0])
    if shuffle:
        np.random.shuffle(idxs)
    return inputs[idxs], targets[idxs]

def split_dataset(X, y, seq_length):
    split_time = round((X.shape[0]//24)*0.8)*24 

    y_train = y[:split_time]
    X_train = X[:split_time]
    y_val = y[split_time:]
    X_val = X[split_time:]
    
    return X_train, y_train, X_val, y_val

def normalize(X):
    mean = X.mean()
    std = X.std()
    return (X-mean)

def plot_train_history(history, title):
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    epochs = range(len(loss))

    plt.figure()

    plt.plot(epochs, loss, 'b', label='Training loss')
    plt.plot(epochs, val_loss, 'r', label='Validation loss')
    plt.title(title)
    plt.legend()

    plt.show()

def multi_step_plot(history, true_future, prediction, steps=24):
    plt.figure(figsize=(12, 6))
    num_out = len(true_future)

    plt.plot(np.arange(num_out)/steps, np.array(true_future), 'bo',
        label='True Future')
    if prediction.any():
        plt.plot(np.arange(num_out)/steps, np.array(prediction), 'ro',
           label='Predicted Future')
    plt.legend(loc='upper left')
    plt.show()

