from utils import get_sequence_inputs, split_dataset, normalize

import pickle
import argparse
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras

def load_model(path):
    net = keras.models.load_model('model')
    return net

def model_predict(model, X):
    return model.predict(X).reshape(-1,1)


def mae(y, y_hat):
    return np.abs(y - y_hat).mean()


if __name__ =="__main__":
    parser = argparse.ArgumentParser('run model')
    parser.add_argument('--data', type=str, default='train.pkl')
    parser.add_argument('--load-path', type=str, default='awesome_model.pt')

    args = parser.parse_args()

    with open(args.data, 'rb') as fp:
        data = pickle.load(fp)

    X = data['x']
    y = data['y']

    X = tf.keras.utils.normalize(X, axis=-1, order=2)
   
    # Divide into sequences
    X_test, y_test = get_sequence_inputs([X, y], 24, 24)
    
    model = load_model(args.load_path)

    X_test_tensor = tf.data.Dataset.from_tensor_slices((X_test, y_test))
    X_test_tensor = X_test_tensor.batch(64)

    y_hat = model_predict(model, X_test_tensor)

    err = mae(y, y_hat)
    print('Mean average error {}'.format(err))
