from utils import get_sequence_inputs, split_dataset, normalize, show_plot, plot_train_history, multi_step_plot

import pickle
import argparse
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras

if __name__ =="__main__":
    
    # passo epoch e batch size come parametri
    parser = argparse.ArgumentParser('train model')
    parser.add_argument('--data', type=str, default='train.pkl')
    
    args = parser.parse_args()

    with open(args.data, 'rb') as fp:
        data = pickle.load(fp)

    batch_size = 64    
    EVALUATION_INTERVAL = 240
    epochs = 100
    sequence_length = 24

    X = data['x']
    y = data['y']

    # Split in train, val and test,
    X_train, y_train, X_val, y_val= split_dataset(X, y, sequence_length)

    # Normalize features
    X_train = tf.keras.utils.normalize(X_train, axis=-1, order=2)
    X_val = tf.keras.utils.normalize(X_val, axis=-1, order=2)

    # Divide into sequences
    X_train, y_train = get_sequence_inputs([X_train, y_train], sequence_length, 24)
    X_val, y_val = get_sequence_inputs([X_val, y_val], sequence_length, 24)


    X_train_tensor = tf.data.Dataset.from_tensor_slices((X_train, y_train))
    X_train_tensor = X_train_tensor.cache().batch(batch_size).repeat()

    X_test_tensor = tf.data.Dataset.from_tensor_slices((X_val, y_val))
    X_test_tensor = X_test_tensor.batch(batch_size).repeat()

    # Model
    callback = tf.keras.callbacks.EarlyStopping(monitor='val_mae', patience=20)

    net = tf.keras.models.Sequential()
    net.add(tf.keras.layers.LSTM(60, 
        return_sequences=True,
        input_shape=X_train.shape[-2:]))       
    net.add(tf.keras.layers.LSTM(60))
    net.add(tf.keras.layers.Dense(30, activation="relu"))
    net.add(tf.keras.layers.Dense(24))

    #lr_schedule = tf.keras.callbacks.LearningRateScheduler(
    #lambda epoch: 1e-8 * 10**(epoch / 20))


    optimizer = tf.keras.optimizers.SGD(lr=1e-3, momentum=0.9)
    #optimizer=keras.optimizers.Adam(lr=1e-3)

    net.compile(loss=tf.keras.losses.Huber(),optimizer=optimizer,metrics=["mae"])

    # Train the model
    history = net.fit(X_train_tensor, epochs=epochs,
        steps_per_epoch=EVALUATION_INTERVAL, callbacks=[callback],
        validation_data=X_test_tensor, validation_steps=50)

    #Plots
    plot_train_history(history,'Single Step Training and validation loss')

    for x, y in X_test_tensor.take(1):
        multi_step_plot(x[0], y[0], net.predict(x)[0])

    net.save("model")
